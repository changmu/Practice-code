#pragma once

enum {
    SIGNIN, MSG, LISTUSER
};

