# EagleEyes
    A subproject to monitor the hardwares' useage condition (eg. cpus, mem, netcard io and ip)
=======================

2016-8-11 15:36:56
    修改了/proc/net/dev中设备名的获取方式
===


---
2016.08.08
    修改了json接收端地址
    增加了配置文件
    增加了一个简陋的日志文件
---
2016.08.05
    修复了文件描述符泄露的bug
---
2016.08.04 update
    将json提交的域名改为了nm.lbase.inc
    修改了hostname的获取方法：当/etc/name存在时读取该文件信息，否则用gethostname函数提取
    新增了一个判断ip连通性的dest ip: '211.98.4.1'
---
2016.08.02 update2
    更改了cpu使用率的计算方式
---
2016.08.02 update
    Repaired a bug
---
2016.08.01 update
    Add threadpool to handle ip's connection test.
---
2016.07.31 update
    Removed threadpool, use probe/ping instead. Changed the remote repository.
---
2016.07.30 update
    Add the partition stat.
---
2016.07.29 update
    Wiped ip's name field.
---
2016.07.28 update
    Altered the format of hostname field.
---
2016.07.26 update 
    Only physical netcards were selected.
