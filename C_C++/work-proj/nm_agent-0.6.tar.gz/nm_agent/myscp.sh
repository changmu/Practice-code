#!/bin/bash

cd ~qiu
pwd
tar zcf w.tar.gz workSpace
workSpace/scp.sh w.tar.gz

# bj04
# scp -P 2121 $1  test@106.38.222.165:/home/test
# cd02phy
# scp -P 2121 $1 qiu@222.211.90.67:/home/qiu
# scp -P 2121 -i ~qiu/.ssh/id_rsa root@183.60.189.19:/root/qiu/probec .