#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <pthread.h>
#include <fcntl.h>
#include <sys/types.h>
#include <pthread.h>
#include <string.h>
#include <ctype.h>

#define THREAD 8
#define FILEPATH "/tmphello.tmp"

#define ERR_EXIT(str) \
    do { \
        perror(str); \
        exit(EXIT_FAILURE); \
    } while (0)

// read from config file.
static int g_intervalSeconds;
static char *g_hostname;
static char *g_target;
char *g_logFile;
char *g_ping;
int g_logFd;

char buf[10000];

static void readConfig()
{
    FILE *fp = fopen("nm_agent.conf", "r");
    if (fp == NULL) {
        ERR_EXIT("can't open config file.");
    }
    char *p = NULL;

    while (fgets(buf, sizeof(buf), fp)) {
        int len = strlen(buf);
        p = strchr(buf, '#');
        if (p != NULL)
            *p = '\0';

        if (buf[0] == '\0' || buf[0] == '\n') // comment or blank line
            continue;

        // wipe trail spaces
        while (len > 0 && isspace(buf[len-1]))
            --len;
        buf[len] = '\0';

        p = strchr(buf, '=');
        if (p == NULL) // invalid key=value pair
            continue;

        *p = '\0'; // key is buf, value is p + 1

        if (strcmp(buf, "target") == 0) {
            g_target = strdup(p + 1);
            printf("debug: target=%s\n", g_target);
        } else if (strcmp(buf, "interval") == 0) {
            g_intervalSeconds = atoi(p + 1);
            printf("debug: interval=%d\n", g_intervalSeconds);
        } else if (strcmp(buf, "name") == 0) {
            g_hostname = strdup(p + 1);
            printf("debug: host=%s\n", g_hostname);
        } else if (strcmp(buf, "ping") == 0) {
            g_ping = strdup(p + 1);
            printf("debug: ping=%s\n", g_ping);
        } else if (strcmp(buf, "log") == 0) {
            g_logFile = strdup(p + 1);
            g_logFd = open(g_logFile, O_CREAT | O_WRONLY | O_TRUNC, 0666);
            if (g_logFd < 0)
                ERR_EXIT("can't open log file.");
            printf("debug: log=%s\n", g_logFile);
        }
    }

    fclose(fp);
}

static void releaseConfig()
{
    // free nullptr is ok.
    free(g_hostname);
    free(g_target);
    free(g_ping);
    free(g_logFile);

    if (g_logFd)
        close(g_logFd);
}

void do_log(const char *str)
{
    time_t now = time(NULL);

    char *ptr = ctime(&now);
    write(g_logFd, ptr, strlen(ptr));
    write(g_logFd, str, strlen(str));    
}

int main(int argc, char *argv[])
{
    readConfig();
    do_log("hello");
    releaseConfig();
    return 0;
}