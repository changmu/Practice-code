#include <unistd.h>
#include <arpa/inet.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ioctl.h>
#include <ifaddrs.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <net/if.h>

#include "ip_stat.h"

#include "jsoncpp/json/json.h"
#include <curl/curl.h>
#include "threadpool.h"

#include <string>
#include <map>
#include <cctype>

// prototype:
// int getifaddrs(struct ifaddrs **ifap);
// void freeifaddrs(struct ifaddrs *ifa);

#define THREAD 4
#define QUEUE  2000

#define ERR_EXIT(str) \
    do { \
        perror(str); \
        exit(EXIT_FAILURE); \
    } while (0)

extern char *g_ping;
extern int g_logFd;

struct interfaceInfo interfaceDevices[MAX_INTERFACE_NUM];

int g_interfaceNums;

std::map<std::string, std::string> nameToMacCache;

static const char *g_scan_fmt1 = "{\"token\": \"\", \"src\": \"%s\", \"dest\": \"114.114.114.114\", \"count\": 5, \"interval\": 1}";
static const char *g_scan_fmt2 = "{\"token\": \"\", \"src\": \"%s\", \"dest\": \"8.8.8.8\", \"count\": 5, \"interval\": 1}";
static const char *g_scan_fmt3 = "{\"token\": \"\", \"src\": \"%s\", \"dest\": \"211.98.4.1\", \"count\": 5, \"interval\": 1}";
    
struct easyHandle_t {
    bool inUse;
    CURL *handle;
    char recv[1024];
} g_easyHandle[THREAD];
static pthread_mutex_t g_easyHandle_mutex;


void getDeviceMac(const char *deviceName, char mac[])
{
    std::string str = nameToMacCache[deviceName];
    if (!str.empty()) {
        strcpy(mac, str.c_str());
        return;
    }

    struct ifreq ifreq;
    int sock;

    sock = socket(AF_INET, SOCK_STREAM, 0);
    if(sock < 0) {
        ERR_EXIT("getDeviceMac:socket");
    }

    strcpy(ifreq.ifr_name, deviceName);
    if(ioctl(sock, SIOCGIFHWADDR, &ifreq) < 0) {
        ERR_EXIT("getDeviceMac::ioctl");
    }

    int i = 0;
    for(i = 0; i < 6; i++) {
        sprintf(mac + 3 * i, "%02X:", (unsigned char)ifreq.ifr_hwaddr.sa_data[i]);
    }
    int len = strlen(mac);
    mac[--len] = 0;
    for (i = 0; i < len; ++i)
        mac[i] = tolower(mac[i]);

    nameToMacCache[deviceName] = mac;
}


static bool isPrivateIp(const char *ip)
{
    static const unsigned A_private = 0x0a000000;
    static const unsigned A_reserve = 0x7f000000;
    static const unsigned B_private = 0xac100000;
    static const unsigned B_reserve = 0xa9fe0000;
    static const unsigned C_private = 0xc0a80000;

    unsigned addr = ntohl((unsigned) inet_addr(ip));

    return (addr >> 24) == (A_private >> 24)
        || (addr >> 24) == (A_reserve >> 24)
        || (addr >> 20) == (B_private >> 20)
        || (addr >> 16) == (B_reserve >> 16)
        || (addr >> 16) == (C_private >> 16);
}


static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp)
{
    size_t realsize = size * nmemb;
    char *buf = (char *) userp;
    if (realsize >= 1000) // in case for buf overflow
        return 0;

    memcpy(buf, contents, realsize);
    buf[realsize] = '\0';

    return realsize;
}

static bool checkIpConnect(const char *scan_fmt, const char *ip, int curl_handle_id)
{
    char buf[1024];
    CURL *curl_handle = g_easyHandle[curl_handle_id].handle;
    CURLcode res;
    sprintf(buf, scan_fmt, ip);
        // printf("debug: %s\n", buf);
    curl_easy_setopt(curl_handle, CURLOPT_POSTFIELDS, buf);
        // printf("debug: line: %d..\n", __LINE__);
    res = curl_easy_perform(curl_handle);
        // printf("debug: line: %d..\n", __LINE__);

    bool flag = false;
    if (res != CURLE_OK) {
        fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
    } else {
        std::string str;
        Json::Reader reader;
        Json::Value value;

        if (reader.parse(g_easyHandle[curl_handle_id].recv, value)) {
            if (value["Count"] != 0)
                flag = true;
        }
    }

    return flag;
}

static int getEasyHandleIdx()
{
    int ret = -1;
    pthread_mutex_lock(&g_easyHandle_mutex);
    for (int i = 0; i < THREAD; ++i)
        if (!g_easyHandle[i].inUse) {
            g_easyHandle[i].inUse = true;
            ret = i;
            break;
        }
    pthread_mutex_unlock(&g_easyHandle_mutex);
    return ret;
}

static void freeEasyHandle(int curl_handle_id)
{
    pthread_mutex_lock(&g_easyHandle_mutex);
    g_easyHandle[curl_handle_id].inUse = false;
    pthread_mutex_unlock(&g_easyHandle_mutex);
}

static void do_task(void *arg)
{
    int ipIdx = *(int *) arg;
    free(arg);
    int curl_handle_id = getEasyHandleIdx();
    if (curl_handle_id == -1)
        ERR_EXIT("getEasyHandleIdx");
    const char *ip = interfaceDevices[ipIdx].ip;

    interfaceDevices[ipIdx].valid = checkIpConnect(g_scan_fmt1, ip, curl_handle_id) 
                                 || checkIpConnect(g_scan_fmt2, ip, curl_handle_id)
                                 || checkIpConnect(g_scan_fmt3, ip, curl_handle_id);

    freeEasyHandle(curl_handle_id);
}

void getIpStat()
{
    /* thread_cnt, queue size */
    threadpool_t *pool = threadpool_create(THREAD, QUEUE, 0);

    int i;
    for (i = 0; i < THREAD; ++i) {
        g_easyHandle[i].inUse = false;
        g_easyHandle[i].handle = curl_easy_init();
        // curl_easy_setopt(g_easyHandle[i].handle, CURLOPT_NOSIGNAL, 1);
        // curl_easy_setopt(g_easyHandle[i].handle, CURLOPT_URL, "http://127.0.0.1:4346/probe/ping");
        curl_easy_setopt(g_easyHandle[i].handle, CURLOPT_URL, g_ping);
        curl_easy_setopt(g_easyHandle[i].handle, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(g_easyHandle[i].handle, CURLOPT_WRITEDATA, (void *) g_easyHandle[i].recv);
    }
    pthread_mutex_init(&g_easyHandle_mutex, NULL);

    struct ifaddrs *ifaStructPtr = NULL;
    struct ifaddrs *ifaPtr = NULL;
    struct in_addr addr;

    int ret = getifaddrs(&ifaStructPtr);
    if (ret == -1)
        ERR_EXIT("getifaddrs");

    char ip[INET_ADDRSTRLEN + 10] = { 0 };


    i = 0; //! for counting the nums of ip
    for (ifaPtr = ifaStructPtr; ifaPtr != NULL; ifaPtr = ifaPtr->ifa_next) {
        if (!ifaPtr->ifa_addr || ifaPtr->ifa_addr->sa_family != AF_INET)
            continue;

        addr = ((struct sockaddr_in *) ifaPtr->ifa_addr)->sin_addr;
        strcpy(ip, inet_ntoa(addr));

        // strcpy(interfaceDevices[i].name, ifaPtr->ifa_name);
        strcpy(interfaceDevices[i].ip, ip);

        getDeviceMac(ifaPtr->ifa_name, interfaceDevices[i].mac);

#if 1
        // filter inner ip
        if (isPrivateIp(ip)) {
            // printf("debug: ip %s\n", ip);
            continue;
        }
#endif
        //! interfaceDevices[i].valid = checkConnect(ip);
        
        // printf("debug: name: %s ip:%s\n", ifaPtr->ifa_name, ip);

        /* check ip */
        int *arg = (int *) malloc(sizeof(int));
        *arg = i;
        threadpool_add(pool, do_task, (void *) arg, 0);
        // printf("debug: line: %d..\n", __LINE__);
        ++i;
    }
    g_interfaceNums = i;

    /* clean up */
    freeifaddrs(ifaStructPtr);
    threadpool_destroy(pool, threadpool_graceful);
    /* cleanup curl stuff */
    for (i = 0; i < THREAD; ++i) {
        curl_easy_cleanup(g_easyHandle[i].handle);
    }
    pthread_mutex_destroy(&g_easyHandle_mutex);
    // curl_global_cleanup(); in main.cc
}

#if 0
int main(int argc, char *argv[])
{
    getIpStat();
    int i;
    char mac[32];
    printf("interface:\n");
    for (i = 0; i < g_interfaceNums; ++i) {
        printf("device name: %s\n", interfaceDevices[i].name);
        printf("MAC: %s\n", mac);
        printf("\tip:%s\n", interfaceDevices[i].ip);
        printf("\tvalid:%d\n", interfaceDevices[i].valid);
    }
    return 0;
}
#endif
