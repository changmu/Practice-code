// #define DEBUG

#include <iostream>
#include <fstream>
#include <string>

#include "jsoncpp/json/json.h"
#include <curl/curl.h>

#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <signal.h>
#include <time.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <ctype.h>

#include "cpu_stat.h"
#include "mem_stat.h"
#include "partition_stat.h"
#include "net_stat.h"


static char buf[100000];

#define ERR_EXIT(str) \
    do { \
        perror(str); \
        exit(EXIT_FAILURE); \
    } while (0)


volatile bool g_stop;

// read from config file.
static int g_intervalSeconds;
static char *g_hostname;
static char *g_target;
char *g_logFile;
char *g_ping;
int g_logFd;

static void readConfig()
{
    FILE *fp = fopen("nm_agent.conf", "r");
    if (fp == NULL) {
        ERR_EXIT("can't open config file.");
    }
    char *p = NULL;

    while (fgets(buf, sizeof(buf), fp)) {
        int len = strlen(buf);
        p = strchr(buf, '#');
        if (p != NULL)
            *p = '\0';

        if (buf[0] == '\0' || buf[0] == '\n') // comment or blank line
            continue;

        // wipe trail spaces
        while (len > 0 && isspace(buf[len-1]))
            --len;
        buf[len] = '\0';

        p = strchr(buf, '=');
        if (p == NULL) // invalid key=value pair
            continue;

        *p = '\0'; // key is buf, value is p + 1

        if (strcmp(buf, "target") == 0) {
            g_target = strdup(p + 1);
        } else if (strcmp(buf, "interval") == 0) {
            g_intervalSeconds = atoi(p + 1);
        } else if (strcmp(buf, "name") == 0) {
            g_hostname = strdup(p + 1);
        } else if (strcmp(buf, "ping") == 0) {
            g_ping = strdup(p + 1);
        } else if (strcmp(buf, "log") == 0) {
            g_logFile = strdup(p + 1);
            g_logFd = open(g_logFile, O_CREAT | O_WRONLY | O_TRUNC, 0666);
            if (g_logFd < 0)
                ERR_EXIT("can't open log file.");
        }
    }

    fclose(fp);
}

static void releaseConfig()
{
    // free nullptr is ok.
    free(g_hostname);
    free(g_target);
    free(g_ping);
    free(g_logFile);

    if (g_logFd)
        close(g_logFd);
}

void do_log(const char *str)
{
    time_t now = time(NULL);

    char *ptr = ctime(&now);
    write(g_logFd, ptr, strlen(ptr));
    write(g_logFd, str, strlen(str));    
}

static void SIGUSR1_handle(int sig)
{
    g_stop = 1;
}

#if 0
static void myNanoSleep(double seconds)
{
    time_t secs = (time_t) seconds;
    double fractional = seconds - secs;

    struct timespec ts;
    ts.tv_sec = secs;
    ts.tv_nsec = (long) (fractional * 1e9);

    int ret;
    do {
        ret = nanosleep(&ts, &ts);
    } while (ret == -1 && errno == EINTR);
}
#endif

void myGethostname(char buf[], size_t len)
{
    int fd = open("/etc/name", O_RDONLY);
    if (fd == -1) {
        gethostname(buf, len);
        char *cp = strchr(buf, '.');
        if (cp != NULL)
            *cp = '\0';
    } else {
        int ret = read(fd, buf, len - 1);
        if (ret <= 0) {
            strcpy(buf, "invalid_name");
            return;
        }
        /* in case that the trail char is '\n' or ' ' */
        while (ret > 0 && isspace(buf[ret - 1]))
            --ret;
        buf[ret] = '\0';

        close(fd);
    }
}

int main(int argc, char *argv[])
{
    signal(SIGUSR1, SIGUSR1_handle);
    readConfig();
#ifdef DEBUG
    FILE *fp = fopen("out.log", "w");
#endif
#ifndef DEBUG
    daemon(0, 0);
#endif
    
    Json::FastWriter writer;
    Json::Value root;
    Json::Value val;
    Json::Value arr;
    Json::Value val2;

    CURL *curl;
    CURLcode res;
    curl_global_init(CURL_GLOBAL_ALL);
    /* get a curl handle */ 
    curl = curl_easy_init();
    if (curl == NULL) {
        do_log("curl_easy_init err.");
        ERR_EXIT("curl_easy_init");
    }
    // curl_easy_setopt(curl, CURLOPT_NOSIGNAL, 1);
    // curl_easy_setopt(curl, CURLOPT_URL, "http://183.60.189.19/stored_baseDB.php");
    // curl_easy_setopt(curl, CURLOPT_URL, "http://nm.lbase.inc/receive");
    curl_easy_setopt(curl, CURLOPT_URL, g_target);

    int i;
    char hostname[1024] = { 0 };
    if (g_hostname)
        strcpy(hostname, g_hostname);
    else
        myGethostname(hostname, sizeof(hostname));
    // printf("hostname:%s\n", hostname);

    while (!g_stop) {
        time_t beginInterval = time(NULL);

        root.clear();

        getNetStat(); // include getIpStat();
        getDiskStat();
        getCpuStat();
        getMemStat();

        // get hostname
        root["hostname"] = hostname;

        
        // get cpu stat
        val.clear();
        arr.clear();
        val["total"] = g_cpusUsageRate[0];
        for (i = 1; i <= g_numsOfCores; ++i) {
            Json::Value subVal;
            subVal["idx"] = i - 1;
            subVal["usage"] = g_cpusUsageRate[i];
            arr.append(subVal);
        }
        val["per_cpu"] = arr;
        root["cpu"] = val;


        // get mem stat 'KB'
        val.clear();
        val["mem_total"] = g_memTotal;
        val["mem_idle"] = g_memIdle;
        val["swap_total"] = g_swapTotal;
        val["swap_idle"] = g_swapFree;
        val["mem_used_rate"] = g_memUsedRate;
        val["swap_used_rate"] = g_swapUsedRate;
        root["mem"] = val;


        // get disk stat 'MB'
        arr.clear();
        for (i = 0; i < g_numsOfPartitions; ++i) {
            val.clear();
            val["name"] = g_partitions[i].name;
            val["mount_dir"] = g_partitions[i].dir;
            val["total_size"] = g_partitions[i].totalSize;
            val["free_size"] = g_partitions[i].freeSize;
            val["used_rate"] = g_partitions[i].usedRate;
            val["rw_ok"] = g_partitions[i].valid;
            arr.append(val);
        }
        val.clear();
        val2.clear();
        // val["name"] = "total";
        val["total_size"] = g_partitions[i].totalSize;
        val["free_size"] = g_partitions[i].freeSize;
        val["used_rate"] = g_partitions[i].usedRate;
        val2["per_disk"] = arr;
        val2["total"] = val;
        root["disk"] = val2;

        // get net stat
        arr.clear();
        for (i = 0; i < g_numsOfNetcards; ++i) {
            val.clear();
            val["name"] = g_netcards[i].name;
            val["mac"] = g_netcards[i].mac;
            val["in_flow"] = g_netcards[i].recvMBitsPerSec;
            val["out_flow"] = g_netcards[i].sendMBitsPerSec;
            val["in_pack"] = g_netcards[i].recvKpacksPerSec;
            val["out_pack"] = g_netcards[i].sendKpacksPerSec;

            Json::Value subArr;
            for (size_t j = 0; j < g_netcards[i].ipInfo.size(); ++j) {
                Json::Value subVal;

                subVal["ipv4"] = g_netcards[i].ipInfo[j]->ip;
                subVal["valid"] = g_netcards[i].ipInfo[j]->valid;
                subArr.append(subVal);
            }
            val["ip"] = subArr;

            arr.append(val);
        }
        // total netcard
        val.clear();
        val["in_flow"] = g_netcards[i].recvMBitsPerSec;
        val["out_flow"] = g_netcards[i].sendMBitsPerSec;
        val["in_pack"] = g_netcards[i].recvKpacksPerSec;
        val["out_pack"] = g_netcards[i].sendKpacksPerSec;

        val2.clear();
        val2["total"] = val;     
        val2["per_netcard"] = arr;
        root["netcard"] = val2;

        time_t leftSeconds = g_intervalSeconds - (time(NULL) - beginInterval);

#ifndef DEBUG
        while (leftSeconds > 0 && !g_stop) {
            sleep(1);
            --leftSeconds;
        }
#endif        
        
        /* Now specify the POST data */ 
        strncpy(buf, writer.write(root).c_str(), sizeof(buf) - 1);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, buf);

        /* Perform the request, res will get the return code */
        res = curl_easy_perform(curl);
        /* Check for errors */
        if(res != CURLE_OK)
            fprintf(stderr, "curl_easy_perform() failed: %s\n", curl_easy_strerror(res));
#ifdef DEBUG
        // std::cout << time(NULL) << std::endl << writer.write(root) << std::endl;

        time_t now = time(NULL);
        fprintf(fp, "time:%s%s", ctime(&now), buf);
        fflush(fp);
#endif
        
    }
    
    curl_easy_cleanup(curl);
    curl_global_cleanup();
    releaseConfig();
#ifdef DEBUG
    fclose(fp);
#endif
    return 0;
}
