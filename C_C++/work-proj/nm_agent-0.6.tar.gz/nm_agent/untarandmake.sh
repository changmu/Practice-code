#!/bin/bash

rm -rf workSpace
tar zxf w.tar.gz
cd workSpace
make clean && make

# bj04
# scp -P 2121 $1  test@106.38.222.165:/home/test
# cd02phy
# scp -P 2121 $1 qiu@222.211.90.67:/home/qiu
# scp -P 2121 -i ~qiu/.ssh/id_rsa root@183.60.189.19:/root/qiu/probec .