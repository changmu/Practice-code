#if 1
#include <curl/curl.h>
#include <unistd.h>
#include <stdio.h>
#include <string.h>


char g_buf[10][1024];
const char *g_ips[] = {
  "183.60.189.19",
  "183.60.189.25",
  "183.60.189.27",
  "183.60.189.26",
};

size_t write_data(void *buffer, size_t size, size_t count, void *user_p)
{
    char *buf = (char *) user_p;
    int realSize = size * count;
    strncpy(buf, (char *) buffer, 1000);
    printf("recv: %s\n", buf);
    if (realSize == strlen(buf))
      printf("ok\n");
    return strlen(buf);
}


int main(int argc, char **argv)
{
#define EASY_HANDLE_NUMS 4
    int i;
    CURL *easy_handle[EASY_HANDLE_NUMS];
    // 初始化
    curl_global_init(CURL_GLOBAL_ALL);
    CURLM *multi_handle = NULL;
    for (i = 0; i < EASY_HANDLE_NUMS; ++i)
      easy_handle[i] = NULL;
    char buf[1024];
    static const char *scan_fmt = "{\"token\": \"\", \"src\": \"%s\", \"dest\": \"8.8.8.8\", \"count\": 10, \"interval\": 1}";



    multi_handle = curl_multi_init();

    // 设置easy handle
    for (i = 0; i < EASY_HANDLE_NUMS; ++i) {
      easy_handle[i] = curl_easy_init();
      curl_easy_setopt(easy_handle[i], CURLOPT_URL, "http://127.0.0.1:4346/probe/ping");
      curl_easy_setopt(easy_handle[i], CURLOPT_WRITEFUNCTION, &write_data);
      curl_easy_setopt(easy_handle[i], CURLOPT_WRITEDATA, g_buf[i]);

      sprintf(buf, scan_fmt, g_ips[i]);
      printf("debug: %s\n", g_ips[i]);
      curl_easy_setopt(easy_handle[i], CURLOPT_POSTFIELDS, buf);
      // curl_easy_setopt(easy_handle[i], CURLOPT_VERBOSE, 1L);
    }

    // 添加到multi stack
    for (i = 0; i < EASY_HANDLE_NUMS; ++i) {
      curl_multi_add_handle(multi_handle, easy_handle[i]);
    }


    int running_handle_count;
    while (CURLM_CALL_MULTI_PERFORM == curl_multi_perform(multi_handle, &running_handle_count)) {
      printf("running_handle_count: %d\n", running_handle_count);
    }

    while (running_handle_count) {
        timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;

        int max_fd;
        fd_set fd_read;
        fd_set fd_write;
        fd_set fd_except;

        FD_ZERO(&fd_read);
        FD_ZERO(&fd_write);
        FD_ZERO(&fd_except);

        curl_multi_fdset(multi_handle, &fd_read, &fd_write, &fd_except, &max_fd);
        int return_code = select(max_fd + 1, &fd_read, &fd_write, &fd_except, &tv);
        if (-1 == return_code) {
            printf("select err.\n");
            break;
        } else {
            while (CURLM_CALL_MULTI_PERFORM == curl_multi_perform(multi_handle, &running_handle_count)) {
                printf("running_handle_count: %d\n", running_handle_count);
            }
        }
    }

    for (i = 0; i < 4; ++i)
      puts(g_buf[i]);

    // 释放资源
    for (i = 0; i < EASY_HANDLE_NUMS; ++i) {
      curl_easy_cleanup(easy_handle[i]);
    }
    curl_multi_cleanup(multi_handle);
    curl_global_cleanup();

    return 0;
}
#endif

#if 0
#include <iostream>
#include <curl/curl.h>

using namespace std;

int main(int argc, char **argv)
{
    // 初始化
    curl_global_init(CURL_GLOBAL_WIN32);
    CURLM *multi_handle = NULL;
    CURL *easy_handle1 = NULL;
    CURL *easy_handle2 = NULL;

    extern size_t save_sina_page(void *buffer, size_t size, size_t count, void *user_p);
    extern size_t save_sohu_page(void *buffer, size_t size, size_t count, void *user_p);
    FILE *fp_sina = fopen("sina.html", "ab+");
    FILE *fp_sohu = fopen("sohu.html", "ab+");

    multi_handle = curl_multi_init();

    // 设置easy handle
    easy_handle1 = curl_easy_init();
    curl_easy_setopt(easy_handle1, CURLOPT_URL, "http://www.sina.com.cn");
    curl_easy_setopt(easy_handle1, CURLOPT_WRITEFUNCTION, &save_sina_page);
    curl_easy_setopt(easy_handle1, CURLOPT_WRITEDATA, fp_sina);

    easy_handle2 = curl_easy_init();
    curl_easy_setopt(easy_handle2, CURLOPT_URL, "http://www.sohu.com");
    curl_easy_setopt(easy_handle2, CURLOPT_WRITEFUNCTION, &save_sina_page);
    curl_easy_setopt(easy_handle2, CURLOPT_WRITEDATA, fp_sohu);

    // 添加到multi stack
    curl_multi_add_handle(multi_handle, easy_handle1);
    curl_multi_add_handle(multi_handle, easy_handle2);


    int running_handle_count;
    while (CURLM_CALL_MULTI_PERFORM == curl_multi_perform(multi_handle, &running_handle_count))
    {
        cout << running_handle_count << endl;
    }

    while (running_handle_count)
    {
        timeval tv;
        tv.tv_sec = 1;
        tv.tv_usec = 0;

        int max_fd;
        fd_set fd_read;
        fd_set fd_write;
        fd_set fd_except;

        FD_ZERO(&fd_read);
        FD_ZERO(&fd_write);
        FD_ZERO(&fd_except);

        curl_multi_fdset(multi_handle, &fd_read, &fd_write, &fd_except, &max_fd);
        int return_code = select(max_fd + 1, &fd_read, &fd_write, &fd_except, &tv);
        if (-1 == return_code)
        {
            cerr << "select error." << endl;
            break;
        }
        else
        {
            while (CURLM_CALL_MULTI_PERFORM == curl_multi_perform(multi_handle, &running_handle_count))
            {
                cout << running_handle_count << endl;
            }
        }
    }

    // 释放资源
    fclose(fp_sina);
    fclose(fp_sohu);
    curl_easy_cleanup(easy_handle1);
    curl_easy_cleanup(easy_handle2);
    curl_multi_cleanup(multi_handle);
    curl_global_cleanup();

    return 0;
}

size_t save_sina_page(void *buffer, size_t size, size_t count, void *user_p)
{
    return fwrite(buffer, size, count, (FILE *)user_p);
}

size_t save_sohu_page(void *buffer, size_t size, size_t count, void *user_p)
{
    return fwrite(buffer, size, count, (FILE *)user_p);
}
#endif